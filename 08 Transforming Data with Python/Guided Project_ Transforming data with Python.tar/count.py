import read
import re
from collections import Counter

def cnt_words(str_list):
    word_list = []
    for s in str_list:
        word_list += list(map(lambda x: x.lower(), re.sub("([.,!?:;'\"-]|\\s)+", ' ', s.strip()).split()))
    word_cnts = {}
    for w in word_list:
        word_cnts[w] = word_cnts.get(w, 0) + 1
    return Counter(word_cnts)

def prnt_top_100(cntr):
    for pair in cntr.most_common(100):
        print(pair[0])

def main():
    hn_stories = read.load_data()
    words = cnt_words(hn_stories['headline'].dropna().tolist())
    prnt_top_100(words)

if __name__ == '__main__':
    main()