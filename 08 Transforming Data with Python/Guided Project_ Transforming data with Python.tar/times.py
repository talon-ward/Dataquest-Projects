import read
import dateutil

def main():
    data = read.load_data()
    print(data['submission_time'].apply(
          lambda x: dateutil.parser.parse(x).hour).value_counts())

if __name__ == '__main__':
    main()