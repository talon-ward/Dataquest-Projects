import read
import count
from collections import Counter

def cnt_dmns(dmn_list):
    dmn_cnts = {}
    for w in dmn_list:
        dmn_cnts[w] = dmn_cnts.get(w, 0) + 1
    return Counter(dmn_cnts)

def main():
    data = read.load_data()
    domains = cnt_dmns(data['url'].dropna().tolist())
    count.prnt_top_100(domains)

if __name__ == '__main__':
    main()