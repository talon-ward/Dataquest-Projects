import pandas as pd

def load_data():
    data = pd.read_csv('hn_stories.csv', names=['submission_time', 'upvotes', 'url', 'headline'])
    return data

def main():
    hn_stories = load_data()
    print(hn_stories.head())

if __name__ == '__main__':
    main()